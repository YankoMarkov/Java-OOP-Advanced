package logger.interfaces;

public interface Writer {
	
	void writeLine(String output);
}
