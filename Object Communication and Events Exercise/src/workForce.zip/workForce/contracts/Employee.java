package workForce.contracts;

public interface Employee {
	
	String getName();
	
	int getWorkHoursPerWeek();
}
