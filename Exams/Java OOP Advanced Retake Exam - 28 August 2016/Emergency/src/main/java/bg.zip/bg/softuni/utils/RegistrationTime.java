package bg.softuni.utils;

public interface RegistrationTime {

    String toString();
}
