package bg.softuni.models.centers;

public class PoliceServiceCenter extends BaseEmergencyCenter {

    public PoliceServiceCenter(String name, Integer amountOfMaximumEmergencies) {
        super(name, amountOfMaximumEmergencies);
    }
}
