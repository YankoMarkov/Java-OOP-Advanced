package bg.softuni.commands;

public interface Executable {

    String execute();
}
