package bg.softuni.io;

public interface Writer {

    void write(String text);
}
