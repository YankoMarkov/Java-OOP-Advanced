package bg.softuni.enums;

public enum Status {
    SPECIAL,
    NON_SPECIAL,

}
