package collectionHierarchy.interfaces;

public interface Addable {
	int add(String str);
}
