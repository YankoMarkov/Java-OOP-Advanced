package collectionHierarchy.interfaces;

public interface Removable {
	String remove();
}
