package collectionHierarchy.interfaces;

public interface Usedable {
	int used();
}
