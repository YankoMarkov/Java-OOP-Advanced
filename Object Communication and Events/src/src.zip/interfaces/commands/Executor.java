package interfaces.commands;

import interfaces.commands.Command;

public interface Executor {
	
	void executeCommand(Command command);
}
