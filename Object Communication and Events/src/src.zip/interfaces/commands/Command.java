package interfaces.commands;

public interface Command {
	
	void execute();
}
