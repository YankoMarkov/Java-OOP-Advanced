package interfaces.observers;

public interface Observer {
	
	void update(int value);
}
