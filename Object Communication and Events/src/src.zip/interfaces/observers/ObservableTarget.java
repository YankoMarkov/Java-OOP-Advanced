package interfaces.observers;

import interfaces.Target;

public interface ObservableTarget extends Target, Subject {
}
